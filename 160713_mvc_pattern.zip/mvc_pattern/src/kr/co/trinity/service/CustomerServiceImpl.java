package kr.co.trinity.service;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.xml.xpath.XPathExpressionException;

import kr.co.trinity.dao.CustomerDAO;
import kr.co.trinity.dao.CustomerDAOIF;
import kr.co.trinity.exception.DulplicateException;
import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.vo.Customer;

public class CustomerServiceImpl implements CustomerServiceIF {
	CustomerDAOIF db=new CustomerDAO();
	XPathParser xp = new XPathParser();
	CmdExcuter ce = new CmdExcuter();
	
	@Override
	public void delete(String id) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		db.delete(id);
	}

	@Override
	public void insert(Customer customer) throws DulplicateException {
		// TODO Auto-generated method stub
		db.insert(customer);
	}

	@Override
	public void update(Customer customer) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		db.update(customer);
	}

	@Override
	public Customer getCustomer(String userId) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		return db.getCustomer(userId);
	}

	@Override
	public ArrayList<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return db.getAllCustomer();
	}
	
	@Override
	public boolean loginCheck(String userId, String password) throws Exception {
		return db.loginCheck(userId, password);
	}
	
	@Override
	public boolean loginCheck(String userId) throws Exception {
		// TODO Auto-generated method stub
		return db.loginCheck(userId);
	}

	@Override
	public String XPathLogin(String dir, String id, String password) throws FileNotFoundException, XPathExpressionException {
		// TODO Auto-generated method stub
		System.out.println("test2");
		return xp.excute(dir, id, password);
	}

	@Override
	public void CmdExcuter(String cmd) {
		// TODO Auto-generated method stub
		ce.excute(cmd);
	}

}
