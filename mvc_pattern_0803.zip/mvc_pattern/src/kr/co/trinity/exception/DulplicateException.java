package kr.co.trinity.exception;

public class DulplicateException extends Exception {

	public DulplicateException() {
		super("Dulplicate ����");
	}

	public DulplicateException(String message) {
		super("Dulplicate ���� : "+message);
	}
	
}
