package kr.co.trinity.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import kr.co.trinity.vo.Product;

public class XPathParser {
	NodeList nodes = null;	
	ArrayList<Product> pdList = new ArrayList<Product>();
	public ArrayList<Product> excute(String dir, String keyWord, String flag) throws FileNotFoundException, XPathExpressionException{
		File d = new File(dir);
		XPathFactory factory = XPathFactory.newInstance();
		XPath xPath = factory.newXPath();
		InputSource inputSource = new InputSource(new FileInputStream(d));
		
		String expression = "/trinity/TSstore/product[itemID/text()= '" + keyWord + "' and hidden/text() = '" + flag + "']";
		
		// ��� �˻�.
		nodes = (NodeList) xPath.evaluate(expression, inputSource, XPathConstants.NODESET);
		
		if(nodes != null && nodes.getLength() > 0) {
			for (int count = 0; count < nodes.getLength(); count++) {
				
				Element el = (Element)nodes.item(count);
				
				Element itemId = (Element)el.getElementsByTagName("itemID").item(0);
				Element price = (Element)el.getElementsByTagName("price").item(0);
				Element descr = (Element)el.getElementsByTagName("description").item(0);
				
				String resultOfitemId = itemId.getFirstChild().getNodeValue();
				int resultOfprice = Integer.parseInt(price.getFirstChild().getNodeValue());
				String resultOfdescr = descr.getFirstChild().getNodeValue();
				
				Product pd = null;
				pd = new Product(resultOfitemId, resultOfprice, resultOfdescr);
				
				pdList.add(pd);
			}
		}
		return pdList;
	}
	
	public Product buildProduct(Element ele) {
		Product pd = null;
		String  itemId = getTextValue(ele, "itemID");
		int 	price  = getIntValue(ele, "price");
		String  descr  = getTextValue(ele, "description");
		String  hidden = getTextValue(ele, "hidden");
		
		System.out.println(hidden);
		
		if(hidden.equals("945231"))
		{
			pd = new Product(itemId, price, descr);
			return pd;
		}
		return pd;
	}
	
	public String getTextValue(Element ele, String tagName) {
		String text = null;
		NodeList nl = ele.getElementsByTagName(tagName);
		
		if(nl != null && nl.getLength() > 0) {
			Element el = (Element)nl.item(0);
			text = el.getFirstChild().getNodeValue();
		}
		return text;
	}
	
	public int getIntValue(Element ele, String tagName) {
		return Integer.parseInt(getTextValue(ele, tagName));
	}
}
