package kr.co.trinity.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Hex;

public class Md5Cipher {
	  public static String getMD5(String source) {
		  String MD5 = ""; 
			try{
				MessageDigest md = MessageDigest.getInstance("MD5"); 
				md.update(source.getBytes()); 
				byte byteData[] = md.digest();
				MD5=Hex.encodeHexString(byteData);
				System.out.println("����: "+source+ "   MD5: "+MD5);
			}catch(NoSuchAlgorithmException e){
				e.printStackTrace(); 
				MD5 = null; 
			}
			return MD5;
	  }
	  
	  public static String getSHA256(String source) {
		  String SHA256 = ""; 
			try{
				MessageDigest md = MessageDigest.getInstance("SHA-256"); 
				md.update(source.getBytes()); 
				byte byteData[] = md.digest();
				SHA256=Hex.encodeHexString(byteData);
			    System.out.println("����: "+source+ "   MD5: "+SHA256);
			}catch(NoSuchAlgorithmException e){
				e.printStackTrace(); 
				SHA256 = null; 
			}
			return SHA256;
	  }

}
