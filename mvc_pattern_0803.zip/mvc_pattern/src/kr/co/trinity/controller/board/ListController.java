package kr.co.trinity.controller.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.BoardServiceImpl;
import kr.co.trinity.service.PagingOperator;
import kr.co.trinity.vo.Board;

public class ListController implements Controller {
   BoardServiceImpl bs = new BoardServiceImpl();;
	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Board> boardList = null;
		ArrayList<Board> temp = null;
		String nextPage = null;
		//data check, business method call, scope data save, view select
		String pageNumber = null, pageSize = null, url = null;
		String keyField = null, keyWord = null;
		int totalCount = 0;
		
		pageNumber = request.getParameter("pageNumber") ;
		pageSize = request.getParameter("pageSize") ;
		totalCount = bs.getTotalCount();
		url = "index.jsp?"; 
		
		PagingOperator pageInfo = bs.paging(pageNumber, pageSize, totalCount, url);
		System.out.println(pageInfo.toString());
		
		keyField = request.getParameter("keyField");
		keyWord = request.getParameter("keyWord");
		
		if(keyField != null && keyField != "") // select 박스를 선택했을 떄.
		{
			if(keyField.equals("name")) // 작성자
			{
				//boardList = bs.getBoardFindByWriter(keyWord);
				pageInfo = bs.paging(pageNumber, pageSize, boardList.size(), url);
				boardList = bs.getBoardFindByWriter(pageInfo.getPageNumber(), pageInfo.getPageSize(), keyWord);
				System.out.println(pageInfo.toString());

				request.setAttribute("keyField", keyField);
				request.setAttribute("keyWord", keyWord);
			}
			else if(keyField.equals("number")) // 글번호
			{
				
			}
			else
			{
				// field가 비어있음.
			}
		}
		else{
			boardList = bs.getAllBoard(pageInfo.getPageSize(), pageInfo.getPageNumber());
		}
		
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("boardList", boardList);
		nextPage="index.jsp?content=board/boardList.jsp";
		
		return nextPage;
	}

}

