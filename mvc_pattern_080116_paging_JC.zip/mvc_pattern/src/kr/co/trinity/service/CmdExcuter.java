package kr.co.trinity.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CmdExcuter {
	String result = new String();
	Process process = null;
	public String excute(String cmd){
		try{
			
			process = Runtime.getRuntime().exec(cmd);
			
			InputStream is = process.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr); 
			
			String line = null;
			while((line = br.readLine()) != null)
			{
				result = result + line + "<br>";
				System.out.println(result);
			}
			process.waitFor();
			
		}catch(Exception e){
			System.err.println(e);			
		}finally{
			if(process!=null)
			process.destroy();
		}
		
		if(cmd.equals("cmd.exe /c exp userid=test/1234 file='c:\\test\\test.dmp'"))
			result = "DB ��� �Ϸ� ";
		
		return result;
	}
}
/*
class StreamGobbler extends Thread
{

    InputStream is;
    String type;
    String result; 
    
    StreamGobbler(InputStream is, String type)
    {
        this.is = is;
        this.type = type;
    }

    public void run()
    {
        try
        {
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line = "";
            while((line = br.readLine()) != null){
                System.out.println(type + ">" + line);
            }
        }
        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
}
*/