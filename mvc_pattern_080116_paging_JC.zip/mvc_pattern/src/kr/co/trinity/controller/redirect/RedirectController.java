package kr.co.trinity.controller.redirect;

import java.net.InetAddress;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;

/**
 * Servlet implementation class RedirectController
 */
public class RedirectController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		InetAddress addr = null;
		boolean trusted = false;
		
		String site = request.getParameter("site");
		
		if(site.equals("http://cafe.naver.com/sec") || site.equals("https://www.facebook.com/trinitysoft"))
		{
			// �ŷڵ��� �ʴ� url �ּҷ� �ڵ� ���� ���� ����� ���úκ� -----
			response.sendRedirect(site);
			return "comitted";
		}
		else 
		{
			// dns lookup ����
			addr = InetAddress.getByName("kisa.or.kr");
		}
		
		//System.out.println(addr);
		//System.out.println(addr.getHostName());
		
		if(addr.getHostName().equals("kisa.or.kr"))
		{
			trusted = true;
		}
		
		if(trusted)
		{
			response.sendRedirect(site);
			return "comitted";
		}
		else
		{
			return "index.jsp?content=login.html";
		}
	}
	

}
