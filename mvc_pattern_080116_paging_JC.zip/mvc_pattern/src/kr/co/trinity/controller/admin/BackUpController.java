package kr.co.trinity.controller.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.CustomerServiceImpl;
/**
 * Servlet implementation class BackUpController
 */
public class BackUpController implements Controller {
	CustomerServiceImpl cs = new CustomerServiceImpl();
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		
		String cmd = request.getParameter("cmd");
		String result = null;
		
		result = cs.CmdExcuter(cmd);
		
		request.setAttribute("result", result);
		
		return "index.jsp?content=administrator/adminpage.jsp";
	}

}
