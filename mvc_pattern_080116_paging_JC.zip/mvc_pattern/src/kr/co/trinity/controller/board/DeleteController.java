package kr.co.trinity.controller.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.service.BoardServiceImpl;

public class DeleteController implements Controller {
	BoardServiceImpl bs = new BoardServiceImpl();
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String nextPage=null;
	   
		int boardNum=Integer.parseInt(request.getParameter("boardNum"));
		
		try {
			bs.delete(boardNum);
			request.setAttribute("message",boardNum+" 번 글이 삭제되었습니다.");
			nextPage="index.jsp?content=result.jsp";
		} catch (RecordNotFoundException e) {
			request.setAttribute("message", e.getMessage());
			nextPage="index.jsp?content=result.jsp";
		}
		
		return nextPage;
	}

}
