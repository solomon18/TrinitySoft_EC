package kr.co.trinity.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.trinity.service.CustomerServiceImpl;

public class LoginController implements Controller {
	CustomerServiceImpl cs = new CustomerServiceImpl();
	@Override
	public String handleRequest(HttpServletRequest request,HttpServletResponse response) {
		String nextPage=null;
		String role=null;
		//data check
		String userId = request.getParameter("userId");
		String password=request.getParameter("password");
				
		boolean loginSuccess=false;
		boolean adminCheck=false;
		
		try{
			loginSuccess = cs.loginCheck(userId,password);
			adminCheck = cs.adminCheck(userId, password);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		if(adminCheck==true)
			role = "admin";
		else
			role = "user";
		
		//view select
		if(loginSuccess){
			//Cookie ����
			Cookie userIdCookie = new Cookie("userId", userId);
			Cookie passwordCookie = new Cookie("password", password);
			Cookie roleCookie = new Cookie("role", role);
			
			userIdCookie.setMaxAge(-1);
			passwordCookie.setMaxAge(-2);
			roleCookie.setMaxAge(-3);
			//userIdCookie.setHttpOnly(true);  
			//passwordCookie.setSecure(true);  
			
			//Cookie setting
			response.addCookie(userIdCookie);
			response.addCookie(passwordCookie);
			response.addCookie(roleCookie);

			HttpSession session=request.getSession(); //request.getSession(true);
			session.setAttribute("userId",userId);
			session.setAttribute("password", password);
		    session.setAttribute("role", role);      			
			
			request.setAttribute("message", "濡�洹�?�� ��???!!");
			nextPage="index.jsp?content=result.jsp";
		}else{
			nextPage="index.jsp?content=login.html";
		}
		
		return nextPage;
		
	}

}
