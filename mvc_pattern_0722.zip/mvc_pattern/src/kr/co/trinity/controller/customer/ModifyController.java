package kr.co.trinity.controller.customer;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.trinity.service.CustomerServiceImpl;
import kr.co.trinity.vo.Customer;
import kr.co.trinity.controller.Controller;
import kr.co.trinity.exception.RecordNotFoundException;

public class ModifyController implements Controller {
	CustomerServiceImpl cs = new CustomerServiceImpl();
	
	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
			String nextPage=null;
		
			HttpSession session=request.getSession();
			String id =(String)session.getAttribute("userId");

			
			try {
			Customer customer = cs.getCustomer(id);

			request.setAttribute("customer", customer);
			
			nextPage="index.jsp?content=customerModify.jsp";
			} catch (RecordNotFoundException e) {
			nextPage="index.jsp?content=error.jsp";
			}
			return nextPage;
			}
	}


	