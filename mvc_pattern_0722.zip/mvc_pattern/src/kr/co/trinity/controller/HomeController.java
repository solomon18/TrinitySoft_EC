package kr.co.trinity.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class HomeController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		 //view select
		 //view select
		HttpSession session=request.getSession();
		String id =(String)session.getAttribute("userId");
		if(id ==null || id.equals(""))
		return "index.jsp?content=login.html";
		else
		return "index.jsp?content=result.jsp";
	}

}
