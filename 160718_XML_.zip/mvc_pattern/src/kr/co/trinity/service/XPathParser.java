package kr.co.trinity.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class XPathParser {
NodeList nodes = null;
	
	public String excute(String dir, String id, String password) throws FileNotFoundException, XPathExpressionException{
		
		String nextPage=null;
		File d = new File(dir);
		XPathFactory factory = XPathFactory.newInstance();
		XPath xPath = factory.newXPath();
		InputSource inputSource = new InputSource(new FileInputStream(d));
		String expression = "trinity/employees/employee[loginID/text()='" + id + "' and passwd/text()='" + password
				+ "']";

		// ��� �˻�.
		nodes = (NodeList) xPath.evaluate(expression, inputSource, XPathConstants.NODESET);
		
		if (nodes.getLength() == 1) nextPage = "index.jsp?content=administrator/adminpage.jsp";
		else if (nodes.getLength() > 1) nextPage = "index.jsp?content=administrator/adminpage.jsp";
			else nextPage = "index.jsp?content=administrator/administrator.jsp";
		
		return nextPage;
	}
}
