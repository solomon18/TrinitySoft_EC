package kr.co.trinity.service;

import java.util.ArrayList;

import kr.co.trinity.dao.BoardDAO;
import kr.co.trinity.dao.BoardDAOIF;
import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.vo.Board;

public class BoardServiceImpl implements BoardServiceIF{
	BoardDAOIF db=new BoardDAO();
	PagingOperator po=new PagingOperator();
	@Override
	public void insert(Board b) {
		// TODO Auto-generated method stub
		db.insert(b);
	}

	@Override
	public void update(Board b) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		db.update(b);
	}

	@Override
	public void delete(int boardNum) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		db.delete(boardNum);
	}

	@Override
	public Board getBoard(int boardNum) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		return db.getBoard(boardNum);
	}

	@Override
	public ArrayList<Board> getAllBoard() {
		// TODO Auto-generated method stub
		return db.getAllBoard();
	}

	@Override
	public ArrayList<Board> getBoardFindByTitle(String title) {
		// TODO Auto-generated method stub
		return db.getBoardFindByTitle(title);
	}

	@Override
	public ArrayList<Board> getBoardFindByWriter(String writer) {
		// TODO Auto-generated method stub
		return db.getBoardFindByWriter(writer);
	}

	@Override
	public int getTotalCount() {
		// TODO Auto-generated method stub
		return db.getTotalCount();
	}

	@Override
	public ArrayList<Board> getAllBoard(int pageSize, int pageNumber) {
		// TODO Auto-generated method stub
		return db.getAllBoard(pageSize, pageNumber);
	}

	@Override
	public PagingOperator paging(String _pageNumber, String _pageSize, int totalCount, String url) {
		// TODO Auto-generated method stub
		return po.excute(_pageNumber, _pageSize, totalCount, url);
	}
	
}
