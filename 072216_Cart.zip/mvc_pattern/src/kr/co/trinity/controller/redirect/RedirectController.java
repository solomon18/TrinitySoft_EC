package kr.co.trinity.controller.redirect;

import java.net.InetAddress;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;

/**
 * Servlet implementation class RedirectController
 */
public class RedirectController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		InetAddress addr = null;
		boolean trusted = false;
		String nextPage = null;
		String site = request.getParameter("site");
		
		if(site == "www.trinitysoft.co.kr")
		{
			addr = InetAddress.getByName("65.61.137.117");
		}
		else if(site == "cafe.naver.com/sec")
		{
			addr = InetAddress.getByName("61.247.193.200");
		}
		else
			addr = InetAddress.getByName("31.13.68.35");
		
		if(addr.getCanonicalHostName().endsWith("www.trinitysoft.co.kr")||
				addr.getCanonicalHostName().endsWith("cafe.naver.com/sec")||
				addr.getCanonicalHostName().endsWith("www.facebook.com/trinitysoft"))
		{
			trusted = true;
		}
		
		if(!trusted)
		{
			response.sendRedirect(site);
			return "comitted";
		}
		//request.setAttribute("dns", "http://www.trinitysoft.co.kr");
		else
		{
			return "index.jsp?content=login.html";
		}
	}
	

}
