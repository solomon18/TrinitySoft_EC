package kr.co.trinity.service;

import java.util.ArrayList;

import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.vo.Cart;
import kr.co.trinity.vo.Product;

public class CartServiceImpl implements CartServiceIF{

	@Override
	public ArrayList<Cart> add(Product p, ArrayList<Cart> c) {
		Cart item = new Cart();
		ArrayList<Cart> tray = c;
		Product product = p;
		
		if(tray.size() < 0 || tray.isEmpty()) {
			tray = new ArrayList<Cart>();
			
			item.setItem(product);
			item.setQuantity(1);
			item.setTotalCost(product.getPrice());
			
			tray.add(item);	
		} else {
			for(Cart eachItem : tray) {
			// if product already exists update
				if(eachItem.equals(product)) {
					eachItem.setQuantity(eachItem.getQuantity() + 1);
					eachItem.setTotalCost(eachItem.getItem().getPrice() * eachItem.getQuantity());
					
				} else { // if product doesn't exist add a product
					item.setItem(product);
					item.setQuantity(1);
					item.setTotalCost(product.getPrice());
					
					tray.add(item);
				}
			}
		}   
		
		return tray;
	}

	@Override
	public ArrayList<Cart> remove(Product p, ArrayList<Cart> c) throws NullPointerException {
		Cart item = new Cart();
		ArrayList<Cart> tray = c;
		Product product = p;
		
		if(tray.size() < 0 || tray.isEmpty()) {
			System.out.println("Empty tray");
			
		} else {
			for(Cart eachItem : tray) {
			// if product already exists update
				if(eachItem.equals(product)) {
					eachItem.setQuantity(0);
					eachItem.setTotalCost(0);
					
				} 
			}
		}   
		
		return tray;
	}

	@Override
	public ArrayList<Cart> update(ArrayList<Cart> c) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Cart> getCart(int boardNum) throws RecordNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PagingOperator paging(String _pageNumber, String _pageSize,
			int totalCount, String url) {
		// TODO Auto-generated method stub
		return null;
	}

}
