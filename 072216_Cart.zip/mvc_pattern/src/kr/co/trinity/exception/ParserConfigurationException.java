package kr.co.trinity.exception;

public class ParserConfigurationException extends Exception {

	public ParserConfigurationException() {
		super("xml �ㅻ�");
	}

	public ParserConfigurationException(String message) {
		super("�ㅻ� 醫�瑜� : "+ message);
	}
}
