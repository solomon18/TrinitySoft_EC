package kr.co.trinity.vo;


public class Cart {
	private Product item;
	private int 	quantity;
	private int		totalCost;
	
	public Product getItem() {
		return item;
	}
	
	public void setItem(Product item) {
		this.item = item;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getTotalCost() {
		return totalCost;
	}
	
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}

	@Override
	public String toString() {
		return "Cart [item=" + item + ", quantity=" + quantity + ", totalCost="
				+ totalCost + "]";
	}
	
}
