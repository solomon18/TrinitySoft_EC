package kr.co.trinity.controller.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.BoardServiceImpl;

/**
 * Servlet implementation class FiledownloadController
 */
public class FiledownloadController implements Controller {
	
	BoardServiceImpl bs = new BoardServiceImpl();
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		String fileName = request.getParameter("fileName");
		String fileFolder = request.getSession().getServletContext().getRealPath("upload");
		String filePath = fileFolder + "\\" + fileName;
		
		bs.fileDownload(response, filePath);
		
		return "comitted";
	}
	

}
