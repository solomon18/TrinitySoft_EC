package kr.co.trinity.exception;

public class ParserConfigurationException extends Exception {

	public ParserConfigurationException() {
		super("xml 오류");
	}

	public ParserConfigurationException(String message) {
		super("오류 종류 : "+ message);
	}
}
