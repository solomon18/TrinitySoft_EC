package kr.co.trinity.controller.customer;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.exception.DuplicateException;
import kr.co.trinity.service.CustomerServiceImpl;
import kr.co.trinity.vo.Customer;

public class SaveController implements Controller {
    CustomerServiceImpl cs = new CustomerServiceImpl();
	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String nextPage=null;
		//data check
		String userId = request.getParameter("userId");
		String password = request.getParameter("password");
		String userName = request.getParameter("userName");
		int age = Integer.parseInt(request.getParameter("age"));
		String email = request.getParameter("email");
		
		//business method ��?�?
		try {
			cs.insert(new Customer(userId, password, userName, age, email));
			
			request.setAttribute("message",userId+"�� �����?���? ������?�����?.");
			nextPage = "index.jsp?content=success.jsp";
		} catch (DuplicateException e) {
			//��?���踰�����? ��?��??�� ����,view select
			request.setAttribute("message", e.getMessage());
			nextPage="index.jsp?content=error.jsp";
		}
	
		return nextPage;
	}

}
