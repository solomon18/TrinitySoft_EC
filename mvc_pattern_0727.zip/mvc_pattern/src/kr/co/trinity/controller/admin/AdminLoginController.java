package kr.co.trinity.controller.admin;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.w3c.dom.NodeList;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.CustomerServiceImpl;

/**
 * Servlet implementation class AdminLoginController
 */
public class AdminLoginController implements Controller {
	CustomerServiceImpl cs = new CustomerServiceImpl();
	NodeList nodes = null;
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		//ArrayList<String> AdminList = new ArrayList<String>();
		
		String nextPage=null;
		////////// ���̵� �н����� ����
		String id = request.getParameter("adminid");
		String password = request.getParameter("adminpassword");
		// xml ���� �˻�.
		String dir = request.getSession().getServletContext().getRealPath("xml/data.xml");
		
		/* �׽�Ʈ��
		if (nodes.getLength() == 1)
		{
			Node node = nodes.item(0);
			String[] arrTokens = node.getTextContent().split("[\\t\\s\\n]+");
			
			AdminList.add(arrTokens[1]);
			AdminList.add(arrTokens[2]);
			nextPage = "index.jsp?content=administrator/adminpage.jsp";
		}
		
		else if (nodes.getLength() > 1)
		{
			for (int i = 0; i < nodes.getLength(); i++)
			{
				Node node = nodes.item(i);
				String[] arrTokens = node.getTextContent().split("[\\t\\s\\n]+");
				
				AdminList.add(arrTokens[1]);
				AdminList.add(arrTokens[2]);
			}
			
			nextPage = "index.jsp?content=administrator/adminpage.jsp";
		}
		
		else
		{
			nextPage = "index.jsp?content=administrator/administrator.jsp";
		}
		*/
		//request.setAttribute("AdminList", AdminList); 
		
		// ������ �̵�. AdminList ����ϵ���... �׽�Ʈ��
		nextPage = cs.XPathLogin(dir, id, password);
		return nextPage;
	}

}
