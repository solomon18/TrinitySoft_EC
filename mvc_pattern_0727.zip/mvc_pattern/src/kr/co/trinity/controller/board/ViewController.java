package kr.co.trinity.controller.board;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.service.BoardServiceImpl;
import kr.co.trinity.vo.Board;

public class ViewController implements Controller {
	BoardServiceImpl bs = new BoardServiceImpl();;
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		String nextPage=null;
	    String mode=null;
		
		int boardNum=Integer.parseInt(request.getParameter("boardNum"));
		
		mode = request.getParameter("mode");
		
		if(mode.equals("private"))
		{
			request.setAttribute("boardNum", boardNum);
			nextPage = "index.jsp?content=inputPassword.jsp";
		}
		else
		{
			try {
				Board board = bs.getBoard(boardNum);
				String test = board.getContents().replaceAll("\n", "<br>");
				board.setContents(test);
				request.setAttribute("board", board);
				nextPage="index.jsp?content=board/boardView.jsp";
			} catch (RecordNotFoundException e) {
				request.setAttribute("message", e.getMessage());
				nextPage="index.jsp?content=result.jsp";
			}
		}
	
		return nextPage;
	}

}
