package kr.co.trinity.controller.store;

import java.io.IOException;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Servlet implementation class ShopController
 */
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.StoreXMLLogic;
import kr.co.trinity.vo.Product;

public class StoreController implements Controller {
	StoreXMLLogic xml = new StoreXMLLogic();
	ArrayList<Product> prodList = new ArrayList<Product>();
	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, ParserConfigurationException, SAXException {
		
		System.out.println("Store 들어옴");
		String dir = request.getSession().getServletContext().getRealPath("xml/data.xml");
		prodList = xml.getXML(dir);
		request.setAttribute("prodList", prodList);
		
		System.out.println("List 들어옴");
		return "index.jsp?content=store/store.jsp";
	}
}



