package kr.co.trinity.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CmdExcuter {
	String result = new String();
	public String excute(String cmd){
		try{
			// ���޹��� ���ɾ� ����
			Process process = Runtime.getRuntime().exec("cmd.exe /c " + cmd);
			
			InputStream is = process.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			
			String line;
			while((line = br.readLine()) != null){
				result = result + line + "<br>";
			}
		}catch(Exception e){
			System.err.println(e);			
		}
		
		return result;
	}
}
