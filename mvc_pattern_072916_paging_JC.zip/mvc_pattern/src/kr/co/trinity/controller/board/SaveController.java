package kr.co.trinity.controller.board;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.BoardServiceImpl;
import kr.co.trinity.vo.Board;

public class SaveController implements Controller {
    BoardServiceImpl bs = new BoardServiceImpl();;
    
    String file;
    String file_name;
    String ori_file_name;
    
    
    String title= null;
	String writer= null;
	String contents = null;
	String filename = null;
	String password = null;
	String e_password = null; // encrypt password
	
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String savePath = "upload";
		int uploadFileSizeLimit = 100 * 1024 * 1024; //최대 파일 크기 100MB
		String encType = "UTF-8";
		
		ServletContext context =  request.getSession().getServletContext();
		String uploadFilePath = context.getRealPath(savePath); // 서버상의 실제 경로 
		//String uploadFilePath = "C:\\Users\\형주\\Desktop\\mvc_pattern\\WebContent";
		
		try{
			MultipartRequest multi = new MultipartRequest(
					request,
					uploadFilePath,
					uploadFileSizeLimit,
					encType,
					//동일한 이름이 존재하면 새로운 이름이 부여됨
					new DefaultFileRenamePolicy());
			
			title= multi.getParameter("title");
			writer= multi.getParameter("writer");
			contents = multi.getParameter("contents");
			filename = multi.getFilesystemName("fileName");
			password = multi.getParameter("password");
			
			Enumeration files = multi.getFileNames();
			
			while(files.hasMoreElements()){
				file = (String) files.nextElement();
				//file_name = multi.getFilesystemName(file);
				ori_file_name = multi.getOriginalFileName(file);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		String nextPage=null;
		
		if(password == null)
			bs.insert(new Board(title, writer, contents, ori_file_name));
		
		else // board password encrypt
		{
			try {
				password = bs.md5Cipher(password);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			bs.insert(new Board(title, writer, contents, ori_file_name, password));
		}
		
		request.setAttribute("filePath", uploadFilePath);
		
		if(password != null)
			request.setAttribute("message", password);
		
		else
			request.setAttribute("message", "글이 등록되었습니다.");
		
		nextPage="index.jsp?content=result.jsp";
		return nextPage;
	}
}
