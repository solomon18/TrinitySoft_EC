package kr.co.trinity.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class CmdExcuter {
	public void excute(String cmd){
		try{
			Process process = Runtime.getRuntime().exec("cmd.exe /k " + cmd);
			
			InputStream is = process.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			
			String line;
			while((line = br.readLine()) != null){
				System.out.println(line);
			}
		}catch(Exception e){
			System.err.println(e);			
		}
	}
}
