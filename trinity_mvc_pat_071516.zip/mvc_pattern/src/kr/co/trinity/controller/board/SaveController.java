package kr.co.trinity.controller.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.dao.BoardDAO;
import kr.co.trinity.dao.BoardDAOIF;
import kr.co.trinity.service.BoardServiceImpl;
import kr.co.trinity.vo.Board;

public class SaveController implements Controller {
    BoardServiceImpl bs = new BoardServiceImpl();;
    
    String file;
    String file_name;
    String ori_file_name;
    
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		
		String savePath = "upload";
		
		int uploadFileSizeLimit = 5 * 1024 * 1024;
		String encType = "UTF-8";
		
		
		ServletContext context =  request.getSession().getServletContext();
		String uploadFilePath = context.getRealPath(savePath);
		
		MultipartRequest multi = new MultipartRequest(
				request,
				uploadFilePath,
				uploadFileSizeLimit,
				encType,
				new DefaultFileRenamePolicy());
		
		Enumeration files = multi.getFileNames();
		
		while(files.hasMoreElements()){
			file = (String) files.nextElement();
			file_name = multi.getFilesystemName(file);
			//以��??���? ����?���? ��濡����� �???�� ����?���� �?�����?.
			ori_file_name = multi.getOriginalFileName(file);
		}
		
		System.out.println(file_name);
		System.out.println(ori_file_name);
		
		String nextPage=null;
		
	    //data check, business method ��?�?, ��?���踰�����? �?�??�����?, view select
		String title= multi.getParameter("title");
		String writer= multi.getParameter("writer");
		String contents = multi.getParameter("contents");
		
		//******file upload ?���?�? ...
		String filename = multi.getFilesystemName("fileName");
		
		/*
		Board bVo = new Board();
		bVo.setTitle(title);
		bVo.setWriter(writer);
		bVo.setContents(contents);
		bVo.setFileName(file_name);
		*/

		//dao.insert(new Board(title, writer, contents, ori_file_name));
		bs.insert(new Board(title, writer, contents, ori_file_name));
		
		request.setAttribute("message", "board save...");
		nextPage="index.jsp?content=result.jsp";
		return nextPage;

	}
}
