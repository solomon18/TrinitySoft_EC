package kr.co.trinity.controller.redirect;

import java.io.IOException;
import java.net.InetAddress;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;

/**
 * Servlet implementation class RedirectController
 */
public class RedirectController implements Controller{

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		boolean trusted = false;
		String nextPage = null;
		
		InetAddress addr = InetAddress.getByName("65.61.137.117");
		
		
		if(addr.getCanonicalHostName().endsWith("www.trinitysoft.co.kr"))
		{
			trusted = true;
		}
		
		if(trusted)
		{
			nextPage = "index.jsp?content=redirect.jsp";	
		}
		
		request.setAttribute("dns", "http://www.trinitysoft.co.kr");
		
		return nextPage;
	}
	

}
