package kr.co.trinity.controller.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.service.BoardServiceImpl;
import kr.co.trinity.vo.Board;

/**
 * Servlet implementation class SecretViewController
 */
public class SecretViewController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		BoardServiceImpl bs = new BoardServiceImpl();
		
		String nextPage = null;
		int boardNum = Integer.parseInt(request.getParameter("boardNum"));
		String password = request.getParameter("password");
		
		
		try {
			Board board = bs.getBoard(boardNum);
			password = bs.md5Cipher(password);
			String test = board.getContents().replaceAll("\n", "<br>");
			board.setContents(test);
			request.setAttribute("board", board);
			
			if(password.equals(board.getPassword()))
				nextPage="index.jsp?content=board/boardView.jsp";
			else
			{
				nextPage="index.jsp?content=result.jsp";
			}
			
		} catch (RecordNotFoundException e) {
			request.setAttribute("message", e.getMessage());
			nextPage="index.jsp?content=result.jsp";
		}
		
		return nextPage;
	}
	
}
