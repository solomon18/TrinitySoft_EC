package kr.co.trinity.vo;

public class Shop {

}
