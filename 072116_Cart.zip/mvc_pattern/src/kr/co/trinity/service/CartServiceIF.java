package kr.co.trinity.service;

import java.util.ArrayList;

import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.vo.Cart;
import kr.co.trinity.vo.Product;;

public interface CartServiceIF {
	public abstract ArrayList<Cart> add(Product p, ArrayList<Cart> c);
	public abstract ArrayList<Cart> remove(Product p, ArrayList<Cart> c);
	public abstract ArrayList<Cart> update(ArrayList<Cart> c);
	public abstract ArrayList<Cart> getCart(int boardNum) throws RecordNotFoundException;
	public abstract PagingOperator paging(String _pageNumber, String _pageSize, int totalCount, String url);
}
