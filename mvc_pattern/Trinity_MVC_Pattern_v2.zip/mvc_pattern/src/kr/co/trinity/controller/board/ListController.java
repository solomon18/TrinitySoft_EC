package kr.co.trinity.controller.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.dao.BoardDAO;
import kr.co.trinity.dao.BoardDAOIF;
import kr.co.trinity.paging.Paging;
import kr.co.trinity.vo.Board;

public class ListController implements Controller {
   BoardDAOIF dao=new BoardDAO();
	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String nextPage=null;
		//data check, business method call, scope�뿉 data save, view select
		
		ArrayList<Board> boardList = dao.getAllBoard();
		request.setAttribute("boardList", boardList);
		nextPage="index.jsp?content=board/boardList.jsp";
		
		String pageNumber = request.getParameter("pageNumber") ;
		String pageSize = request.getParameter("pageSize") ;
		int totalCount = dao.getTotalCount();
		
		String url = nextPage; 
		String command = "List" ; 
		Paging pageInfo
			= new Paging(pageNumber, pageSize, totalCount, nextPage, command) ;
		
		System.out.println(pageInfo.toString());
		request.setAttribute("pageInfo", pageInfo);
		return nextPage;
	}

}
