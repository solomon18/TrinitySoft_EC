package kr.co.trinity.controller.board;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.vo.Paging;

public class PagingController implements Controller {

	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String nextPage = null;
		String pageNumber = null, pageSize = null, url = null, command = null;
		int totalCount = 0;
		
		Paging pageInfo
		= new Paging(pageNumber, pageSize, totalCount, nextPage) ;
		
		return null;
	}

}
