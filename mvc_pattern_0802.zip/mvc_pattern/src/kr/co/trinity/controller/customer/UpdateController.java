package kr.co.trinity.controller.customer;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.exception.RecordNotFoundException;
import kr.co.trinity.service.CustomerServiceImpl;
import kr.co.trinity.vo.Customer;

public class UpdateController implements Controller {
    CustomerServiceImpl cs = new CustomerServiceImpl();
	@Override
	public String handleRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String nextPage=null;
		
		//data check
		
		String userId = request.getParameter("userId");
		String userNum = request.getParameter("userNum");
		System.out.println(userNum);
		String userName = request.getParameter("userName");
		int age = Integer.parseInt(request.getParameter("age"));
		String email = request.getParameter("email");
		String password = request.getParameter("newPassword");

		//business method
		try {
			cs.update(new Customer(userId, password, userName, age, email, userNum));
			
			request.setAttribute("message",userId+"정보가 수정되었습니다.");
			nextPage = "index.jsp?content=result.jsp";
		} catch (RecordNotFoundException e) {
			//,view select
			request.setAttribute("message", e.getMessage());
			nextPage="index.jsp?content=error.jsp";
		}
	
		return nextPage;
	}

}
