package kr.co.trinity.controller;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.trinity.service.CustomerServiceImpl;

public class LoginController implements Controller {
	CustomerServiceImpl cs = new CustomerServiceImpl();
	@Override
	public String handleRequest(HttpServletRequest request,HttpServletResponse response) {
		String nextPage=null;
		String role=null;
		String userNum =null;
		//data check
		String userId = request.getParameter("userId");
		String password=request.getParameter("password");
				
		boolean loginSuccess=false;
		boolean adminCheck=false;

		
		try{
			loginSuccess = cs.loginCheck(userId,password);
			adminCheck = cs.adminCheck(userId, password);
			//Customer customer = cs.getCustomer(userId);
			userNum = cs.getUserNum(userId);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		if(adminCheck==true)
			role = "admin";
		else
			role = "user";
		
		//view select
		if(loginSuccess){
			//Cookie ����
			Cookie userIdCookie = new Cookie("userId", userId);
			Cookie passwordCookie = new Cookie("password", password);
			Cookie roleCookie = new Cookie("role", role);
			Cookie userNumCookie = new Cookie("userNum", String.valueOf(userNum));
			
			userIdCookie.setMaxAge(-1);
			passwordCookie.setMaxAge(-2);
			roleCookie.setMaxAge(-3);
			userNumCookie.setMaxAge(-3);
			//userIdCookie.setHttpOnly(true);  
			//passwordCookie.setSecure(true);  
			
			//Cookie setting
			response.addCookie(userIdCookie);
			response.addCookie(passwordCookie);
			response.addCookie(roleCookie);
			response.addCookie(userNumCookie);

			HttpSession session=request.getSession(); //request.getSession(true);
			session.setAttribute("userId",userId);
			session.setAttribute("password", password);
		    session.setAttribute("role", role);      	
		    session.setAttribute("userNum", userNum);
			
		    try {
				request.setCharacterEncoding("utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
			nextPage="board?action=boardList";
		}else{
			nextPage="index.jsp?content=login.html";
		}
		
		return nextPage;
		
	}

}
