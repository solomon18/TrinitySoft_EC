package kr.co.trinity.controller.store;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.trinity.controller.Controller;
import kr.co.trinity.service.XPathParser;
import kr.co.trinity.vo.Product;

/**
 * Servlet implementation class SearchController
 */
public class SearchController implements Controller {
	ArrayList<Product> prodList = new ArrayList<Product>();
	@Override
	public String handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		XPathParser xPath = new XPathParser();
		
		String flag = request.getParameter("value");
		String keyWord = request.getParameter("keyWord");
		String dir = request.getSession().getServletContext().getRealPath("xml/data.xml");
		
		prodList = xPath.excute(dir, keyWord, flag);
		request.setAttribute("prodList", prodList);
		return "index.jsp?content=store/store.jsp";
	}

}
